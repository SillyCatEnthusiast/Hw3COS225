public class Patient {
int ID;
double caffiene;
Patient(int ID, double caffiene){
    this.ID = ID;
    this.caffiene = caffiene;

}
}
